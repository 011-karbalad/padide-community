import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface UserProfile {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  joinedAt: string
}

interface UserStore {
  user: UserProfile | null
  isLoggedIn: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  updateProfile: (profile: Partial<UserProfile>) => void
  setUser: (user: UserProfile) => void
}

// Mock user for demo
const mockUser: UserProfile = {
  id: '1',
  name: 'علی محمدی',
  email: 'ali@example.com',
  phone: '09123456789',
  joinedAt: '1402/01/15',
}

export const useUserStore = create<UserStore>()(
  persist(
    (set) => ({
      user: null,
      isLoggedIn: false,

      login: async (email: string, password: string) => {
        // Mock login
        if (email && password.length >= 6) {
          set({
            user: { ...mockUser, email },
            isLoggedIn: true,
          })
          return true
        }
        return false
      },

      logout: () => {
        set({
          user: null,
          isLoggedIn: false,
        })
      },

      updateProfile: (profile) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...profile } : null,
        }))
      },

      setUser: (user) => {
        set({
          user,
          isLoggedIn: true,
        })
      },
    }),
    {
      name: 'user-store',
    }
  )
)
