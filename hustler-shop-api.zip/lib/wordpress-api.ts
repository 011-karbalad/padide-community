/**
 * WordPress WooCommerce API Integration
 * Backend: https://hustlershop.ir
 * Authenticated with Consumer Key & Secret
 */

const STORE_URL = process.env.NEXT_PUBLIC_WC_STORE_URL || 'https://hustlershop.ir'
const CONSUMER_KEY = process.env.NEXT_PUBLIC_WC_CONSUMER_KEY || ''
const CONSUMER_SECRET = process.env.NEXT_PUBLIC_WC_CONSUMER_SECRET || ''
const WORDPRESS_API_BASE = `${STORE_URL}/wp-json/wc/v3`

// Helper function to get authorization header
function getAuthHeader() {
  if (!CONSUMER_KEY || !CONSUMER_SECRET) {
    console.log('[WooCommerce] Missing API credentials - using fallback')
    return {}
  }
  
  // Use btoa for browser-compatible base64 encoding
  try {
    const credentials = btoa(`${CONSUMER_KEY}:${CONSUMER_SECRET}`)
    return {
      'Authorization': `Basic ${credentials}`,
    }
  } catch (err) {
    console.error('[WooCommerce] Failed to encode credentials:', err)
    return {}
  }
}

export interface WPProduct {
  id: number
  name: string
  slug: string
  description: string
  short_description: string
  price: string
  regular_price: string
  sale_price: string
  discount_percentage?: number
  stock_quantity: number
  rating: number
  review_count: number
  images: Array<{ id: number; src: string; alt: string }>
  categories: Array<{ id: number; name: string }>
  sku: string
}

export interface WPCategory {
  id: number
  name: string
  slug: string
  description: string
  count: number
}

export interface WPOrder {
  id: number
  number: string
  status: string
  date_created: string
  total: string
  customer_id: number
  line_items: Array<{ id: number; product_id: number; quantity: number; total: string }>
}

export interface WCCartItem {
  key: string
  product_id: number
  variation_id: number
  quantity: number
  data_hash: string
  line_tax: string
  line_subtotal: string
  line_subtotal_tax: string
  line_total: string
  data?: any
}

export interface WCCart {
  cart_contents: Record<string, WCCartItem>
  cart_totals: {
    subtotal: string
    subtotal_tax: string
    shipping_total: string
    shipping_tax: string
    total_tax: string
    total: string
  }
}

// Fetch products from WordPress WooCommerce
export async function fetchWPProducts(params?: {
  page?: number
  per_page?: number
  search?: string
  category?: number
  orderby?: string
  order?: 'asc' | 'desc'
}) {
  try {
    const queryParams = new URLSearchParams()
    queryParams.append('per_page', (params?.per_page || 20).toString())
    if (params?.page) queryParams.append('page', params.page.toString())
    if (params?.search) queryParams.append('search', params.search)
    if (params?.category) queryParams.append('category', params.category.toString())
    if (params?.orderby) queryParams.append('orderby', params.orderby)
    if (params?.order) queryParams.append('order', params.order)

    const url = `${WORDPRESS_API_BASE}/products?${queryParams}`
    console.log('[v0] Fetching products from:', url)
    console.log('[v0] Store URL:', STORE_URL)
    console.log('[v0] Has credentials:', !!(CONSUMER_KEY && CONSUMER_SECRET))

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      next: { revalidate: 600 }, // Cache for 10 minutes
    })

    console.log('[v0] Response status:', response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`[WooCommerce] Error ${response.status}:`, errorText)
      throw new Error(`WooCommerce API error: ${response.status}`)
    }

    const products = await response.json() as WPProduct[]
    console.log(`[v0] Successfully fetched ${products.length} products from WooCommerce`)
    return products
  } catch (error) {
    console.error('[WooCommerce API] Error fetching products:', error)
    console.log('[v0] Returning empty array as fallback')
    return []
  }
}

// Fetch single product
export async function fetchWPProduct(id: string | number) {
  try {
    const response = await fetch(`${WORDPRESS_API_BASE}/products/${id}`, {
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      next: { revalidate: 600 },
    })

    if (!response.ok) {
      console.error(`[WooCommerce] Product ${id} not found: ${response.status}`)
      throw new Error(`Product not found: ${id}`)
    }

    return await response.json() as WPProduct
  } catch (error) {
    console.error('[WooCommerce API] Error fetching product:', error)
    return null
  }
}

// Fetch categories
export async function fetchWPCategories() {
  try {
    const response = await fetch(`${WORDPRESS_API_BASE}/products/categories?per_page=50`, {
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      next: { revalidate: 3600 },
    })

    if (!response.ok) {
      throw new Error('Failed to fetch categories')
    }

    return await response.json() as WPCategory[]
  } catch (error) {
    console.error('[WooCommerce API] Error fetching categories:', error)
    return []
  }
}

// Search products
export async function searchWPProducts(query: string) {
  return fetchWPProducts({
    search: query,
    per_page: 20,
  })
}

// Get featured/best-seller products
export async function fetchWPFeaturedProducts() {
  return fetchWPProducts({
    per_page: 10,
    orderby: 'popularity',
  })
}

// Format price in Persian
export function formatWPPrice(price: string | number): string {
  const numPrice = typeof price === 'string' ? parseFloat(price) : price
  return new Intl.NumberFormat('fa-IR', {
    style: 'currency',
    currency: 'IRR',
  }).format(numPrice)
}

// Calculate discount percentage
export function calculateDiscount(originalPrice: string | number, salePrice: string | number): number {
  const original = typeof originalPrice === 'string' ? parseFloat(originalPrice) : originalPrice
  const sale = typeof salePrice === 'string' ? parseFloat(salePrice) : salePrice

  if (original <= 0) return 0
  return Math.round(((original - sale) / original) * 100)
}

// Create WooCommerce Order
export async function createWCOrder(orderData: {
  customer_id?: number
  customer_email: string
  customer_first_name: string
  customer_last_name: string
  phone_number: string
  billing: {
    first_name: string
    last_name: string
    address_1: string
    city: string
    state: string
    postcode: string
    country: string
    email: string
    phone: string
  }
  shipping: {
    first_name: string
    last_name: string
    address_1: string
    city: string
    state: string
    postcode: string
    country: string
  }
  line_items: Array<{
    product_id: number
    quantity: number
  }>
  payment_method: string
  payment_method_title: string
  status?: string
}) {
  try {
    const response = await fetch(`${WORDPRESS_API_BASE}/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(orderData),
    })

    if (!response.ok) {
      console.error(`[WooCommerce] Order creation failed: ${response.status}`)
      throw new Error(`Failed to create order: ${response.status}`)
    }

    const order = await response.json()
    console.log('[v0] Order created successfully:', order.id)
    return order as WPOrder
  } catch (error) {
    console.error('[WooCommerce API] Error creating order:', error)
    return null
  }
}

// Get customer orders
export async function fetchCustomerOrders(customerId: number) {
  try {
    const response = await fetch(
      `${WORDPRESS_API_BASE}/orders?customer=${customerId}`,
      {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader(),
        },
        next: { revalidate: 300 },
      }
    )

    if (!response.ok) {
      throw new Error(`Failed to fetch orders: ${response.status}`)
    }

    return await response.json() as WPOrder[]
  } catch (error) {
    console.error('[WooCommerce API] Error fetching orders:', error)
    return []
  }
}

// Get single order
export async function fetchWCOrder(orderId: number) {
  try {
    const response = await fetch(`${WORDPRESS_API_BASE}/orders/${orderId}`, {
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      next: { revalidate: 300 },
    })

    if (!response.ok) {
      throw new Error(`Order not found: ${orderId}`)
    }

    return await response.json() as WPOrder
  } catch (error) {
    console.error('[WooCommerce API] Error fetching order:', error)
    return null
  }
}

// Transform WP product to local Product type
export function transformWPProduct(wpProduct: WPProduct) {
  return {
    id: wpProduct.id.toString(),
    slug: wpProduct.slug,
    name: wpProduct.name,
    nameEn: wpProduct.name,
    brand: wpProduct.categories?.[0]?.name || 'نامعلوم',
    model: wpProduct.sku || '',
    category: wpProduct.categories?.[0]?.name || 'غیر‌دسته‌بندی',
    categorySlug: wpProduct.categories?.[0]?.slug || 'uncategorized',
    price: parseFloat(wpProduct.price || '0'),
    originalPrice: parseFloat(wpProduct.regular_price || wpProduct.price || '0'),
    thumbnail: wpProduct.images?.[0]?.src || '/placeholder.svg',
    images: wpProduct.images?.map(img => img.src) || [],
    stock: wpProduct.stock_quantity || 0,
    rating: wpProduct.rating || 0,
    reviewCount: wpProduct.review_count || 0,
    sold: 0,
    description: wpProduct.description || wpProduct.short_description || '',
    specifications: {},
    tags: [],
    sku: wpProduct.sku,
    discount: wpProduct.sale_price && wpProduct.regular_price 
      ? calculateDiscount(wpProduct.regular_price, wpProduct.sale_price)
      : 0,
  }
}
