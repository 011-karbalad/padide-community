'use client'

import { useState, useEffect } from 'react'
import useSWR from 'swr'
import {
  fetchWPProducts,
  fetchWPCategories,
  transformWPProduct,
  fetchWPProduct,
} from '@/lib/wordpress-api'
import type { Product } from '@/lib/types'

const fetcher = async (url: string) => {
  const response = await fetch(url)
  if (!response.ok) throw new Error('Failed to fetch')
  return response.json()
}

export function useWCProducts(params?: {
  page?: number
  perPage?: number
  search?: string
  category?: number
  sort?: string
}) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true)
        setError(null)

        const wpProducts = await fetchWPProducts({
          page: params?.page || 1,
          per_page: params?.perPage || 20,
          search: params?.search,
          category: params?.category,
          orderby: params?.sort === 'price-asc' ? 'price' : params?.sort === 'newest' ? 'date' : 'popularity',
          order: params?.sort === 'price-asc' ? 'asc' : 'desc',
        })

        const transformed = wpProducts.map(p => transformWPProduct(p))
        setProducts(transformed)
        console.log(`[v0] Loaded ${transformed.length} products`)
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'خطا در بارگذاری محصولات'
        setError(errorMsg)
        console.error('[useWCProducts] Error:', err)
      } finally {
        setLoading(false)
      }
    }

    loadProducts()
  }, [params?.page, params?.perPage, params?.search, params?.category, params?.sort])

  return {
    products,
    loading,
    error,
  }
}

// Fetch single product
export function useWCProduct(productId: string | number) {
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadProduct = async () => {
      try {
        setLoading(true)
        const wpProduct = await fetchWPProduct(productId)
        if (wpProduct) {
          setProduct(transformWPProduct(wpProduct))
        } else {
          setError('محصول یافت نشد')
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'خطا در بارگذاری محصول')
        console.error('[useWCProduct] Error:', err)
      } finally {
        setLoading(false)
      }
    }

    if (productId) {
      loadProduct()
    }
  }, [productId])

  return {
    product,
    loading,
    error,
  }
}

// Fetch categories
export function useWCCategories() {
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const cats = await fetchWPCategories()
        setCategories(cats)
      } catch (err) {
        console.error('[useWCCategories] Error:', err)
      } finally {
        setLoading(false)
      }
    }

    loadCategories()
  }, [])

  return {
    categories,
    loading,
  }
}
