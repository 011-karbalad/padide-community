import { NextResponse } from 'next/server'

export async function GET() {
  const STORE_URL = process.env.NEXT_PUBLIC_WC_STORE_URL || 'https://hustlershop.ir'
  const CONSUMER_KEY = process.env.NEXT_PUBLIC_WC_CONSUMER_KEY || ''
  const CONSUMER_SECRET = process.env.NEXT_PUBLIC_WC_CONSUMER_SECRET || ''

  console.log('[API] Testing WooCommerce connection')
  console.log('[API] Store URL:', STORE_URL)
  console.log('[API] Has Consumer Key:', !!CONSUMER_KEY)
  console.log('[API] Has Consumer Secret:', !!CONSUMER_SECRET)

  try {
    // Test basic connection without auth first
    const testUrl = `${STORE_URL}/wp-json/wc/v3/products?per_page=1`
    
    console.log('[API] Testing endpoint:', testUrl)
    
    const response = await fetch(testUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })

    console.log('[API] Response status:', response.status)
    console.log('[API] Response ok:', response.ok)

    const data = await response.json()
    
    return NextResponse.json({
      success: response.ok,
      status: response.status,
      productCount: Array.isArray(data) ? data.length : 0,
      message: response.ok ? 'WooCommerce API is accessible' : 'API returned error',
      credentials: {
        hasKey: !!CONSUMER_KEY,
        hasSecret: !!CONSUMER_SECRET,
      },
      data: Array.isArray(data) ? data.slice(0, 1) : data,
    })
  } catch (error) {
    console.error('[API] Test failed:', error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      credentials: {
        hasKey: !!CONSUMER_KEY,
        hasSecret: !!CONSUMER_SECRET,
      },
    }, { status: 500 })
  }
}
